// 탭 인터랙션 구현
document.addEventListener("DOMContentLoaded", function () {
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".tab-content");

  tabButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      const targetId = btn.getAttribute("data-target");

      // 모든 탭/콘텐츠 비활성화
      tabButtons.forEach(function (b) {
        b.classList.remove("active");
      });
      tabContents.forEach(function (c) {
        c.classList.remove("active");
      });

      // 현재 탭/콘텐츠 활성화
      btn.classList.add("active");
      const targetContent = document.getElementById(targetId);
      if (targetContent) {
        targetContent.classList.add("active");
      }
    });
  });
});
